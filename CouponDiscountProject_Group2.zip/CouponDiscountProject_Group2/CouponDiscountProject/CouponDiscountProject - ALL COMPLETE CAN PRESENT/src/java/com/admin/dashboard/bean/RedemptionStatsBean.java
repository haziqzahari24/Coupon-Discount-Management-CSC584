package com.admin.dashboard.bean;

public class RedemptionStatsBean {
    private int redeemed;
    private int active;
    private int expired;
    private int percentageDiscount;
    private int fixedAmount;
    private int freeShipping;
    private int bogo;
    private int totalCoupons;
    private int totalFeedback;
    private int activeUsers;

    public int getRedeemed() {
        return redeemed;
    }
    public void setRedeemed(int redeemed) {
        this.redeemed = redeemed;
    }

    public int getActive() {
        return active;
    }
    public void setActive(int active) {
        this.active = active;
    }

    public int getExpired() {
        return expired;
    }
    public void setExpired(int expired) {
        this.expired = expired;
    }
    
    public int getPercentageDiscount() {
    return percentageDiscount;
    }

    public void setPercentageDiscount(int percentageDiscount) {
        this.percentageDiscount = percentageDiscount;
    }

    public int getFixedAmount() {
        return fixedAmount;
    }

    public void setFixedAmount(int fixedAmount) {
        this.fixedAmount = fixedAmount;
    }

    public int getFreeShipping() {
        return freeShipping;
    }

    public void setFreeShipping(int freeShipping) {
        this.freeShipping = freeShipping;
    }

    public int getBogo() {
        return bogo;
    }

    public void setBogo(int bogo) {
        this.bogo = bogo;
    }
    
    public int getTotalCoupons() {
    return totalCoupons;
    }

    public void setTotalCoupons(int totalCoupons) {
        this.totalCoupons = totalCoupons;
    }

    public int getTotalFeedback() {
    return totalFeedback;
    }

    public void setTotalFeedback(int totalFeedback) {
        this.totalFeedback = totalFeedback;
    }

    public int getActiveUsers() {
        return activeUsers;
    }

    public void setActiveUsers(int activeUsers) {
        this.activeUsers = activeUsers;
    }
}
