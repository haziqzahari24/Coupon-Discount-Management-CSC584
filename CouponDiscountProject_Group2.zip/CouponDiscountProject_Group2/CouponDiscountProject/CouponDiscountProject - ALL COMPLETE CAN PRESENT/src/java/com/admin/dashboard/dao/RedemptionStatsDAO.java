package com.admin.dashboard.dao;

import com.admin.dashboard.bean.RedemptionStatsBean;
import java.sql.*;
import java.time.LocalDate;

public class RedemptionStatsDAO {
    public RedemptionStatsBean getRedemptionStats() {
        RedemptionStatsBean stats = new RedemptionStatsBean();

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/CouponDiscountSystemDB", "app", "app");

            // Redeemed
            String redeemedSQL = "SELECT COUNT(*) FROM CLAIMED_COUPONS WHERE payment_status = 'paid'";
            PreparedStatement ps1 = conn.prepareStatement(redeemedSQL);
            ResultSet rs1 = ps1.executeQuery();
            if (rs1.next()) stats.setRedeemed(rs1.getInt(1));

            // Active
            String activeSQL = "SELECT COUNT(*) FROM COUPONS WHERE code NOT IN (SELECT coupon_code FROM CLAIMED_COUPONS)";
            PreparedStatement ps2 = conn.prepareStatement(activeSQL);
            ResultSet rs2 = ps2.executeQuery();
            if (rs2.next()) stats.setActive(rs2.getInt(1));

            // Expired
            String expiredSQL = "SELECT COUNT(*) FROM COUPONS WHERE expiry_date < ?";
            PreparedStatement ps3 = conn.prepareStatement(expiredSQL);
            ps3.setDate(1, Date.valueOf(LocalDate.now()));
            ResultSet rs3 = ps3.executeQuery();
            if (rs3.next()) stats.setExpired(rs3.getInt(1));
            
            // Percentage Discount
            String percentageDiscountSQL = "SELECT COUNT(*) FROM COUPONS WHERE coupon_type = 'percentage'";
            PreparedStatement ps4 = conn.prepareStatement(percentageDiscountSQL);
            ResultSet rs4 = ps4.executeQuery();
            if (rs4.next()) stats.setPercentageDiscount(rs4.getInt(1));
            
            // Fixed Amount
            String fixedAmountSQL = "SELECT COUNT(*) FROM COUPONS WHERE coupon_type = 'fixed'";
            PreparedStatement ps5 = conn.prepareStatement(fixedAmountSQL);
            ResultSet rs5 = ps5.executeQuery();
            if (rs5.next()) stats.setFixedAmount(rs5.getInt(1));
            
            // Free Shipping
            String freeShippingSQL = "SELECT COUNT(*) FROM COUPONS WHERE coupon_type = 'free_shipping'";
            PreparedStatement ps6 = conn.prepareStatement(freeShippingSQL);
            ResultSet rs6 = ps6.executeQuery();
            if (rs6.next()) stats.setFreeShipping(rs6.getInt(1));
            
            // Buy One Get One
            String bogoSQL = "SELECT COUNT(*) FROM COUPONS WHERE coupon_type = 'bogo'";
            PreparedStatement ps7 = conn.prepareStatement(bogoSQL);
            ResultSet rs7 = ps7.executeQuery();
            if (rs7.next()) stats.setBogo(rs7.getInt(1));
            
            // Total Coupons
            String totalCouponsSQL = "SELECT COUNT(*) FROM COUPONS";
            PreparedStatement ps8 = conn.prepareStatement(totalCouponsSQL);
            ResultSet rs8 = ps8.executeQuery();
            if (rs8.next()) stats.setTotalCoupons(rs8.getInt(1));
            
            // Coupons Claimed
            String totalFeedbackSQL = "SELECT COUNT(*) FROM FEEDBACK";
            PreparedStatement ps9 = conn.prepareStatement(totalFeedbackSQL);
            ResultSet rs9 = ps9.executeQuery();
            if (rs9.next()) stats.setTotalFeedback(rs9.getInt(1));
            
            // Active Users
            String activeUsersSQL = "SELECT COUNT(*) FROM USERS";
            PreparedStatement ps10 = conn.prepareStatement(activeUsersSQL);
            ResultSet rs10 = ps10.executeQuery();
            if (rs10.next()) stats.setActiveUsers(rs10.getInt(1));

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return stats;
    }
}
