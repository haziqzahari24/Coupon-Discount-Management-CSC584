package com.admin.dashboard.main;

import com.admin.dashboard.bean.RedemptionStatsBean;
import com.admin.dashboard.dao.RedemptionStatsDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/RedemptionStatsServlet")
public class RedemptionStatsAServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        RedemptionStatsDAO dao = new RedemptionStatsDAO();
        RedemptionStatsBean stats = dao.getRedemptionStats();

        request.setAttribute("stats", stats);
        request.getRequestDispatcher("adminDashboard.jsp").forward(request, response);
    }
}
