package com.admin.edit.coupon;

import com.admin.edit.coupon.bean.ChangeCouponBean;
import com.admin.edit.coupon.dao.ChangeCouponDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/ChangeCouponServlet")
public class ChangeCouponAServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        ChangeCouponBean coupon = new ChangeCouponBean();
        coupon.setOriginalCode(request.getParameter("originalCode"));
        coupon.setCode(request.getParameter("code"));
        coupon.setCouponType(request.getParameter("couponType"));
        coupon.setDiscount(request.getParameter("discount"));
        coupon.setExpiryDate(request.getParameter("expiryDate"));
        coupon.setDescription(request.getParameter("description"));
        coupon.setCouponTitle(request.getParameter("couponTitle"));
        coupon.setAmount(Integer.parseInt(request.getParameter("amount")));

        ChangeCouponDAO dao = new ChangeCouponDAO();
        boolean updated = dao.updateCoupon(coupon);

        if (updated) {
            response.sendRedirect("EditCouponServlet?success=edit");
        } else {
            response.sendRedirect("EditCouponServlet?error=edit");
        }
    }
}
