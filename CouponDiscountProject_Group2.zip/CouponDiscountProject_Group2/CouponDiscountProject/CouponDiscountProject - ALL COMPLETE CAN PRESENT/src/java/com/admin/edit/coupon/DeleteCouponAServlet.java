package com.admin.edit.coupon;

import com.admin.edit.coupon.dao.DeleteCouponDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/DeleteCouponServlet")
public class DeleteCouponAServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String code = request.getParameter("code");

        boolean isDeleted = DeleteCouponDAO.deleteCoupon(code);

        if (isDeleted) {
            response.sendRedirect("EditCouponServlet?success=delete");
        } else {
            response.sendRedirect("EditCouponServlet?error=delete");
        }
    }
}
