package com.admin.edit.coupon;

import com.admin.edit.coupon.bean.EditCouponBean;
import com.admin.edit.coupon.dao.EditCouponDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/EditCouponServlet")
public class EditCouponAServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("adminUser") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        EditCouponDAO dao = new EditCouponDAO();
        List<EditCouponBean> allCoupons = dao.getAllCoupons();

        request.setAttribute("allCoupons", allCoupons);
        request.getRequestDispatcher("adminEditCoupon.jsp").forward(request, response);
    }
}
