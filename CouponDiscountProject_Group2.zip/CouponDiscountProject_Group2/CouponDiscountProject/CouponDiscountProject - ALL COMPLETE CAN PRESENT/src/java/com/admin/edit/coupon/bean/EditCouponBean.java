package com.admin.edit.coupon.bean;

import java.time.LocalDate;

public class EditCouponBean {
    private String code;
    private String couponType;
    private String discount;
    private LocalDate expiryDate;
    private String description;
    private String couponTitle;
    private String formattedExpiryDate;
    private int amount;

    // Getters and Setters
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getCouponType() { return couponType; }
    public void setCouponType(String couponType) { this.couponType = couponType; }

    public String getDiscount() { return discount; }
    public void setDiscount(String discount) { this.discount = discount; }

    public LocalDate getExpiryDate() { return expiryDate; }
    public void setExpiryDate(LocalDate expiryDate) { this.expiryDate = expiryDate; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getCouponTitle() { return couponTitle; }
    public void setCouponTitle(String couponTitle) { this.couponTitle = couponTitle; }
    
    public String getFormattedExpiryDate() {return formattedExpiryDate;}
    public void setFormattedExpiryDate(String formattedExpiryDate) {this.formattedExpiryDate = formattedExpiryDate;}
    
    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
