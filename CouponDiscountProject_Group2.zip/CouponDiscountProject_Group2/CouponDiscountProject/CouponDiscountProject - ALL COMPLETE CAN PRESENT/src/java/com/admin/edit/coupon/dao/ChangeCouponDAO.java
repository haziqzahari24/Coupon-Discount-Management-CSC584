package com.admin.edit.coupon.dao;

import com.admin.edit.coupon.bean.ChangeCouponBean;
import java.sql.*;

public class ChangeCouponDAO {
    private final String jdbcURL = "jdbc:derby://localhost:1527/CouponDiscountSystemDB";
    private final String jdbcUsername = "app";
    private final String jdbcPassword = "app";

    public boolean updateCoupon(ChangeCouponBean coupon) {
        String sql = "UPDATE COUPONS SET code=?, coupon_type=?, discount=?, expiry_date=?, description=?, title=?, amount=? WHERE code=?";
        try (Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, coupon.getCode());
            stmt.setString(2, coupon.getCouponType());
            stmt.setString(3, coupon.getDiscount());
            stmt.setDate(4, Date.valueOf(coupon.getExpiryDate()));
            stmt.setString(5, coupon.getDescription());
            stmt.setString(6, coupon.getCouponTitle());
            stmt.setInt(7, coupon.getAmount());
            stmt.setString(8, coupon.getOriginalCode());
            

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
