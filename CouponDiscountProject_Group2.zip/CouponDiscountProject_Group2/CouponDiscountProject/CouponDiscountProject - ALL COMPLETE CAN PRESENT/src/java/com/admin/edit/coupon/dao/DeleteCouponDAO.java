package com.admin.edit.coupon.dao;

import java.sql.*;

public class DeleteCouponDAO {

    private static final String DB_URL = "jdbc:derby://localhost:1527/CouponDiscountSystemDB";
    private static final String DB_USER = "app";
    private static final String DB_PASS = "app";

    public static boolean deleteCoupon(String code) {
        String sql = "DELETE FROM COUPONS WHERE CODE = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, code);
            int rowsAffected = stmt.executeUpdate();

            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Other existing methods...
}
