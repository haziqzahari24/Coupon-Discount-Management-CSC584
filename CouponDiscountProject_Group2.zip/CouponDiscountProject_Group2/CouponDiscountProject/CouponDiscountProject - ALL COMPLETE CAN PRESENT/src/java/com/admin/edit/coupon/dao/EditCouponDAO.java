package com.admin.edit.coupon.dao;

import com.admin.edit.coupon.bean.EditCouponBean;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.time.format.DateTimeFormatter;

public class EditCouponDAO {
    private final String jdbcURL = "jdbc:derby://localhost:1527/CouponDiscountSystemDB";
    private final String jdbcUser = "app";
    private final String jdbcPass = "app";

    public List<EditCouponBean> getAllCoupons() {
        List<EditCouponBean> coupons = new ArrayList<>();
        String sql = "SELECT * FROM COUPONS";

        try (Connection conn = DriverManager.getConnection(jdbcURL, jdbcUser, jdbcPass);
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                EditCouponBean coupon = new EditCouponBean();
                coupon.setCode(rs.getString("code"));
                coupon.setCouponType(rs.getString("coupon_type"));
                coupon.setDiscount(rs.getString("discount"));
//
                Date expiry = rs.getDate("expiry_date");
                if (expiry != null) {
//                    coupon.setExpiryDate(expiry.toLocalDate());
                    
                    LocalDate localExpiry = expiry.toLocalDate(); // declared here
                    coupon.setExpiryDate(localExpiry); // set LocalDate

                    // Format to dd-MM-yyyy
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                    String formatted = localExpiry.format(formatter); // use it here
                    coupon.setFormattedExpiryDate(formatted);
                }

                coupon.setDescription(rs.getString("description"));
                coupon.setCouponTitle(rs.getString("title"));
                coupon.setAmount(rs.getInt("amount"));

                coupons.add(coupon);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return coupons;
    }
}
