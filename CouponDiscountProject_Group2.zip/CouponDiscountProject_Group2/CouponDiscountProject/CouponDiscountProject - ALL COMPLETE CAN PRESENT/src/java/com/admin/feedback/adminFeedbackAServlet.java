package com.admin.feedback;

import com.admin.feedback.bean.AdminFeedbackBean;
import com.admin.feedback.dao.AdminFeedbackDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/adminFeedbackServlet")
public class adminFeedbackAServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        AdminFeedbackDAO dao = new AdminFeedbackDAO();
        List<AdminFeedbackBean> feedbackList = dao.getAllFeedback();

        request.setAttribute("feedbackList", feedbackList);
        request.getRequestDispatcher("adminFeedback.jsp").forward(request, response);
    }
}
