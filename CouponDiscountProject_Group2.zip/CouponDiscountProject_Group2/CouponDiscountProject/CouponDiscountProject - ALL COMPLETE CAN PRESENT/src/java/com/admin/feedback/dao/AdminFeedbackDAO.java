package com.admin.feedback.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.admin.feedback.bean.AdminFeedbackBean;

public class AdminFeedbackDAO {
    private final String URL = "jdbc:derby://localhost:1527/CouponDiscountSystemDB";
    private final String USER = "app";
    private final String PASS = "app";

    public List<AdminFeedbackBean> getAllFeedback() {
        List<AdminFeedbackBean> feedbackList = new ArrayList<>();

        String sql = "SELECT name, email, feedback FROM feedback ORDER BY name ASC";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                AdminFeedbackBean fb = new AdminFeedbackBean();
                fb.setName(rs.getString("name"));
                fb.setEmail(rs.getString("email"));
                fb.setFeedback(rs.getString("feedback"));
                feedbackList.add(fb);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return feedbackList;
    }
}
