package com.admin.manage.coupon;

import com.admin.manage.coupon.bean.CouponBean;
import com.admin.manage.coupon.dao.CouponDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/CreateCouponServlet")
public class CreateCouponAServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get form data
        String title = request.getParameter("title");
        String code = request.getParameter("code");
        String description = request.getParameter("description");
        String couponType = request.getParameter("couponType");
        String discountStr = request.getParameter("discount");
        String expiryDate = request.getParameter("expiryDate");
        Integer amount = Integer.valueOf(request.getParameter("amount"));

//        double discount = 0;
//        try {
//            discount = Double.parseDouble(discountStr);
//        } catch (NumberFormatException e) {
//            discount = 0.0;
//        }

        CouponBean coupon = new CouponBean();
        coupon.setTitle(title);
        coupon.setCode(code);
        coupon.setDescription(description);
        coupon.setCouponType(couponType);
        coupon.setDiscount(discountStr);
        coupon.setExpiryDate(expiryDate);
        coupon.setAmount(amount);

        CouponDAO dao = new CouponDAO();
        boolean success = dao.insertCoupon(coupon);

        if (success) {
            response.sendRedirect("manageCoupon.jsp?success=1");
        } else {
            response.sendRedirect("manageCoupon.jsp?error=1");
        }
    }
}
