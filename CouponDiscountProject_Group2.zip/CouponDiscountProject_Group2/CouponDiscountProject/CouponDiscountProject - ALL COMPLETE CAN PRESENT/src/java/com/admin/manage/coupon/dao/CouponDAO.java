package com.admin.manage.coupon.dao;
import java.util.ArrayList;
import java.util.List;

import com.admin.manage.coupon.bean.CouponBean;
import java.sql.*;

public class CouponDAO {
    private final String jdbcURL = "jdbc:derby://localhost:1527/CouponDiscountSystemDB";
    private final String jdbcUser = "app";
    private final String jdbcPassword = "app";

    public boolean insertCoupon(CouponBean coupon) {
        String sql = "INSERT INTO COUPONS (title, code, description, discount, expiry_date, coupon_type, amount) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection conn = DriverManager.getConnection(jdbcURL, jdbcUser, jdbcPassword);
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, coupon.getTitle());
            ps.setString(2, coupon.getCode());
            ps.setString(3, coupon.getDescription());
            ps.setString(4, coupon.getDiscount());
            ps.setDate(5, Date.valueOf(coupon.getExpiryDate())); // Format: yyyy-MM-dd
            ps.setString(6, coupon.getCouponType());
            ps.setInt(7, coupon.getAmount());

            int rows = ps.executeUpdate();
            ps.close();
            conn.close();

            return rows > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public List<CouponBean> getAllCoupons() {
    List<CouponBean> coupons = new ArrayList<>();
    String sql = "SELECT * FROM COUPONS";

    try {
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        Connection conn = DriverManager.getConnection(jdbcURL, jdbcUser, jdbcPassword);
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);

        while (rs.next()) {
            CouponBean coupon = new CouponBean();
            coupon.setTitle(rs.getString("title"));
            coupon.setCode(rs.getString("code"));
            coupon.setDescription(rs.getString("description"));
            coupon.setDiscount(rs.getString("discount"));
            coupon.setExpiryDate(rs.getDate("expiry_date").toString());
            coupon.setCouponType(rs.getString("coupon_type"));

            coupons.add(coupon);
        }

        rs.close();
        stmt.close();
        conn.close();
    } catch (Exception e) {
        e.printStackTrace();
    }

    return coupons;
}
    
}
