package com.coupon.claim;

import com.coupon.claim.bean.ClaimCouponBean;
import com.coupon.claim.dao.ClaimCouponDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/AllCouponServlet")
public class AllCouponUServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String couponCode = request.getParameter("couponCode");
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");

        if (username == null || couponCode == null || couponCode.isEmpty()) {
            response.sendRedirect("login.jsp");
            return;
        }

        ClaimCouponBean bean = new ClaimCouponBean();
        bean.setUsername(username);
        bean.setCouponCode(couponCode);

        ClaimCouponDAO dao = new ClaimCouponDAO();
        boolean success = dao.claimCoupon(bean);

        if (success) {
            response.sendRedirect("myCoupons.jsp?status=success");
        } else {
            response.sendRedirect("claimCoupon.jsp?status=fail");
        }
    }
}
