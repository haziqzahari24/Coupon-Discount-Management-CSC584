package com.coupon.claim;

import com.coupon.claim.bean.ClaimedCouponBean;
import com.coupon.claim.dao.ClaimedCouponDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/CancelCouponServlet")
public class CancelCouponPServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String couponCode = request.getParameter("couponCode");
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");

        if (username == null || couponCode == null || couponCode.trim().isEmpty()) {
            response.sendRedirect("login.jsp");
            return;
        }

        ClaimedCouponBean bean = new ClaimedCouponBean(username, couponCode);
        ClaimedCouponDAO dao = new ClaimedCouponDAO();

        try {
            boolean result = dao.deleteClaimedCoupon(bean);
            if (result) {
                response.sendRedirect("myCoupons.jsp?status=cancel_success");
            } else {
                response.sendRedirect("myCoupons.jsp?status=cancel_fail");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("myCoupons.jsp?status=error");
        }
    }
}
