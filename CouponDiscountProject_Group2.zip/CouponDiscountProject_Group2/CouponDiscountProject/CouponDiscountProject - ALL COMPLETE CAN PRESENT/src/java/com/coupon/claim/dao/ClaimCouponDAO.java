package com.coupon.claim.dao;

import java.sql.*;

import com.coupon.claim.bean.ClaimCouponBean;

public class ClaimCouponDAO {

    public boolean claimCoupon(ClaimCouponBean bean) {
        boolean isClaimed = false;
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection(
                "jdbc:derby://localhost:1527/CouponDiscountSystemDB", "app", "app");

            String sql = "INSERT INTO claimed_coupons (username, coupon_code) VALUES (?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, bean.getUsername());
            pstmt.setString(2, bean.getCouponCode());

            int rows = pstmt.executeUpdate();
            isClaimed = rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (Exception ignored) {}
            try { if (conn != null) conn.close(); } catch (Exception ignored) {}
        }

        return isClaimed;
    }
}
