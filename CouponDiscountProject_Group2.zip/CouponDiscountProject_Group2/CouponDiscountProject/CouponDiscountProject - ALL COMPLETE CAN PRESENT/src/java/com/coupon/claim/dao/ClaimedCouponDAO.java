package com.coupon.claim.dao;

import java.sql.*;
import com.coupon.claim.bean.ClaimedCouponBean;

public class ClaimedCouponDAO {
    private final String JDBC_URL = "jdbc:derby://localhost:1527/CouponDiscountSystemDB";
    private final String JDBC_USER = "app";
    private final String JDBC_PASS = "app";

    public boolean deleteClaimedCoupon(ClaimedCouponBean bean) throws ClassNotFoundException {
        boolean deleted = false;
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);

            String sql = "DELETE FROM claimed_coupons WHERE username = ? AND coupon_code = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, bean.getUsername());
            pstmt.setString(2, bean.getCouponCode());

            int rows = pstmt.executeUpdate();
            deleted = rows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (Exception ignored) {}
            try { if (conn != null) conn.close(); } catch (Exception ignored) {}
        }

        return deleted;
    }
}
