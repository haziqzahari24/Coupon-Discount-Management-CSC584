package com.coupon.feedback;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.coupon.feedback.bean.FeedbackBean;
import com.coupon.feedback.dao.FeedbackDAO;

@WebServlet("/SubmitFeedbackServlet")
public class SubmitFeedbackPServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get form data
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String product = request.getParameter("product");
        String feedback = request.getParameter("feedback");
        String contactPermissionParam = request.getParameter("contactPermission");
        boolean contactPermission = contactPermissionParam != null;

        // Set to bean
        FeedbackBean fb = new FeedbackBean();
        fb.setName(name);
        fb.setEmail(email);
        fb.setProduct(product);
        fb.setFeedback(feedback);
        fb.setContactPermission(contactPermission);

        // Insert via DAO
        FeedbackDAO dao = new FeedbackDAO();
        boolean result = dao.insertFeedback(fb);

        if (result) {
            response.sendRedirect("feedback.jsp?status=success");
        } else {
            response.sendRedirect("feedback.jsp?status=fail");
        }
    }
}
