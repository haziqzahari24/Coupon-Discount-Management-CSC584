package com.coupon.feedback.bean;

public class FeedbackBean {
    private String name;
    private String email;
    private String product;
    private String feedback;
    private boolean contactPermission;

    // Getters
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getProduct() { return product; }
    public String getFeedback() { return feedback; }
    public boolean isContactPermission() { return contactPermission; }

    // Setters
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setProduct(String product) { this.product = product; }
    public void setFeedback(String feedback) { this.feedback = feedback; }
    public void setContactPermission(boolean contactPermission) { this.contactPermission = contactPermission; }
}
