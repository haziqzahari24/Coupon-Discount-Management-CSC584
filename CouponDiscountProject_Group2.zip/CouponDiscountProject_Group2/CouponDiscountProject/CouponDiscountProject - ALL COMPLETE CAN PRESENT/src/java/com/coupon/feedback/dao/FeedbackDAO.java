package com.coupon.feedback.dao;

import java.sql.*;
import com.coupon.feedback.bean.FeedbackBean;

public class FeedbackDAO {

    private final String JDBC_URL = "jdbc:derby://localhost:1527/CouponDiscountSystemDB";
    private final String JDBC_USER = "app";
    private final String JDBC_PASS = "app";

    public boolean insertFeedback(FeedbackBean fb) {
        boolean success = false;
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);

            String sql = "INSERT INTO feedback (name, email, product, feedback, contact_permission) VALUES (?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, fb.getName());
            stmt.setString(2, fb.getEmail());
            stmt.setString(3, fb.getProduct());
            stmt.setString(4, fb.getFeedback());
            stmt.setBoolean(5, fb.isContactPermission());

            int rows = stmt.executeUpdate();
            success = rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }

        return success;
    }
}
