package com.coupon.home.dao;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import com.coupon.home.bean.HomeBean;

public class HomeDAO {
    public List<HomeBean> getFeaturedCoupons() throws Exception {
        List<HomeBean> list = new ArrayList<>();
        
        // Load Derby driver
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/CouponDiscountSystemDB", "app", "app");

        String sql = "SELECT * FROM coupons WHERE expiry_date >= CURRENT_DATE "
                + "AND code NOT IN (SELECT coupon_code FROM CLAIMED_COUPONS)"
                + "order by expiry_date asc FETCH FIRST 6 ROWS ONLY";
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        // Loop to fill list with HomeBean objects
        while (rs.next()) {
            HomeBean bean = new HomeBean();
            bean.setTitle(rs.getString("title"));
            bean.setCode(rs.getString("code"));
            bean.setDescription(rs.getString("description"));
            bean.setDiscount(rs.getString("discount"));
            bean.setAmount(rs.getInt("amount"));

            java.sql.Date expiry = rs.getDate("expiry_date");

            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
            String formattedDate = formatter.format(expiry);
            bean.setExpiryDate(formattedDate);
            list.add(bean);
        }

        // Close resources
        rs.close();
        ps.close();
        con.close();

        return list;
    }
    
    public List<HomeBean> getFeaturedCouponsAllCoupon() throws Exception {
        List<HomeBean> list = new ArrayList<>();
        
        // Load Derby driver
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/CouponDiscountSystemDB", "app", "app");

        String sql = "SELECT * FROM coupons WHERE expiry_date >= CURRENT_DATE "
                + "AND code NOT IN (SELECT coupon_code FROM CLAIMED_COUPONS) order by expiry_date asc";
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            HomeBean bean = new HomeBean();
            bean.setTitle(rs.getString("title"));
            bean.setCode(rs.getString("code"));
            bean.setDescription(rs.getString("description"));
            bean.setDiscount(rs.getString("discount"));
            bean.setAmount(rs.getInt("amount"));

            java.sql.Date expiry = rs.getDate("expiry_date");

            // Format date as DD/MM/YYYY
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
            String formattedDate = formatter.format(expiry);
            bean.setExpiryDate(formattedDate);
            list.add(bean);
        }

        // Close resources
        rs.close();
        ps.close();
        con.close();

        return list;
    }
}
