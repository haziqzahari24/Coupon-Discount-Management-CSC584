package com.coupon.login;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.coupon.login.bean.LoginBean;
import com.coupon.login.dao.LoginDAO;
import com.admin.dashboard.bean.RedemptionStatsBean;
import com.admin.dashboard.dao.RedemptionStatsDAO;

@WebServlet("/LoginServlet")
public class LoginUServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if (username == null || password == null || username.trim().isEmpty() || password.trim().isEmpty()) {
            request.setAttribute("error", "Username and password are required.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }

        try {
            LoginDAO loginDAO = new LoginDAO();
            LoginBean user = loginDAO.validateUser(username, password);

            if (user != null) {
                HttpSession session = request.getSession(true);
                session.setAttribute("username", user.getUsername());
                session.setAttribute("role", user.getRole());

                if ("admin".equalsIgnoreCase(user.getRole())) {
                    session.setAttribute("adminUser", user.getUsername());

                    // Load admin dashboard data
                    RedemptionStatsDAO dao = new RedemptionStatsDAO();
                    RedemptionStatsBean stats = dao.getRedemptionStats();

                    request.setAttribute("stats", stats);
                    request.getRequestDispatcher("adminDashboard.jsp").forward(request, response);
                } else {
                    // Redirect normal users to home page
                    response.sendRedirect("home.jsp");
                }

            } else {
                request.setAttribute("error", "Invalid username or password.");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            request.setAttribute("error", "Server error: " + ex.getMessage());
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
