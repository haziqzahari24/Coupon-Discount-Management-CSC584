package com.coupon.login;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.coupon.login.bean.RegisterBean;
import com.coupon.login.dao.RegisterDAO;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    @Override
    public void init() throws ServletException {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException ex) {
            throw new ServletException("Derby driver not found", ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // 1. Collect form data
        String username        = req.getParameter("username");
        String fullName        = req.getParameter("full_name");
        String email           = req.getParameter("email");
        String phone           = req.getParameter("phone_number");
        String password        = req.getParameter("password");
        String confirmPassword = req.getParameter("confirm_password");

        // 2. Basic validation
        if (username == null || fullName == null || email == null ||
            password == null  || confirmPassword == null ||
            !password.equals(confirmPassword)) {

            req.setAttribute("error", "Invalid input or passwords do not match.");
            req.getRequestDispatcher("index.jsp").forward(req, resp);
            return;
        }

        // 3. Populate the bean
        RegisterBean user = new RegisterBean();
        user.setUsername(username);
        user.setFullName(fullName);
        user.setEmail(email);
        user.setPhoneNumber(phone);
        user.setPassword(password);

        try {
            // 4. Insert using DAO
            RegisterDAO dao = new RegisterDAO();
            boolean success = dao.registerUser(user);

            if (success) {
                resp.sendRedirect("login.jsp");
            } else {
                req.setAttribute("error", "Registration failed.");
                req.getRequestDispatcher("index.jsp").forward(req, resp);
            }

        } catch (SQLIntegrityConstraintViolationException dup) {
            req.setAttribute("error", "Username or email already exists.");
            req.getRequestDispatcher("index.jsp").forward(req, resp);

        } catch (SQLException e) {
            req.setAttribute("error", "Database error: " + e.getMessage());
            req.getRequestDispatcher("index.jsp").forward(req, resp);

        } catch (Exception e) {
            throw new ServletException("Registration failed", e);
        }
    }
}
