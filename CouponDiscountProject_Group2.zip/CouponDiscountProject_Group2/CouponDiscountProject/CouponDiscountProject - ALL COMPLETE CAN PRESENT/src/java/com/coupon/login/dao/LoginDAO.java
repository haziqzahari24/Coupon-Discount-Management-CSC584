package com.coupon.login.dao;

import java.sql.*;

import com.coupon.login.bean.LoginBean;

public class LoginDAO {
    private static final String JDBC_URL = "jdbc:derby://localhost:1527/CouponDiscountSystemDB";
    private static final String JDBC_USER = "app";
    private static final String JDBC_PASS = "app";

    public LoginBean validateUser(String username, String password) {
        LoginBean user = null;

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");

            String sql = "SELECT user_id, role FROM Users WHERE username = ? AND password = ?";
            try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
                 PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, username.trim());
                ps.setString(2, password);

                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    user = new LoginBean();
                    user.setUsername(username);
                    user.setPassword(password);
                    user.setRole(rs.getString("role"));
                    user.setUserId(rs.getInt("user_id"));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return user;
    }
}
