package com.coupon.login.dao;

import com.coupon.login.bean.RegisterBean;
import java.sql.*;

public class RegisterDAO {
    private static final String JDBC_URL  = "jdbc:derby://localhost:1527/CouponDiscountSystemDB";
    private static final String JDBC_USER = "app";
    private static final String JDBC_PASS = "app";

    public boolean registerUser(RegisterBean user) throws SQLException {
        String sql = "INSERT INTO Users (username, password, email, full_name, phone_number) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, user.getUsername().trim());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getEmail().trim().toLowerCase());
            ps.setString(4, user.getFullName().trim());
            ps.setString(5, user.getPhoneNumber() != null ? user.getPhoneNumber().trim() : null);

            ps.executeUpdate();
            return true;
        }
    }
}
