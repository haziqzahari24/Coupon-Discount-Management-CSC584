package com.coupon.profile;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.coupon.profile.bean.UserBean;
import com.coupon.profile.dao.UserDAO;

@WebServlet("/UpdateProfileServlet")
public class UpdateProfilePServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");

        if (username == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String password = request.getParameter("password");
        String email = request.getParameter("email");
        String fullName = request.getParameter("fullName");
        String phoneNumber = request.getParameter("phoneNumber");

        // Set data to bean
        UserBean user = new UserBean();
        user.setUsername(username);
        user.setPassword(password);
        user.setEmail(email);
        user.setFullName(fullName);
        user.setPhoneNumber(phoneNumber);

        // Call DAO
        UserDAO dao = new UserDAO();
        boolean result = dao.updateUser(user);

        if (result) {
            response.sendRedirect("profile.jsp?status=update_success");
        } else {
            response.sendRedirect("profile.jsp?status=update_fail");
        }
    }
}
