package com.coupon.profile.dao;

import java.sql.*;
import com.coupon.profile.bean.UserBean;

public class UserDAO {

    private final String JDBC_URL = "jdbc:derby://localhost:1527/CouponDiscountSystemDB";
    private final String JDBC_USER = "app";
    private final String JDBC_PASS = "app";

    public boolean updateUser(UserBean user) {
        boolean success = false;
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);

            String sql = "UPDATE users SET password=?, email=?, full_name=?, phone_number=? WHERE username=?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, user.getPassword());
            stmt.setString(2, user.getEmail());
            stmt.setString(3, user.getFullName());
            stmt.setString(4, user.getPhoneNumber());
            stmt.setString(5, user.getUsername());

            int rowsUpdated = stmt.executeUpdate();
            success = rowsUpdated > 0;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }

        return success;
    }
}
